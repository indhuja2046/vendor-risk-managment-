import sqlite3
import pandas as pd

DB_NAME = "vendors.db"

def get_connection():
    return sqlite3.connect(DB_NAME)

def create_table():
    conn = get_connection()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS vendors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vendor TEXT UNIQUE NOT NULL,
            category TEXT DEFAULT 'General',
            location TEXT DEFAULT '',
            contract_value REAL DEFAULT 0,
            criticality TEXT DEFAULT 'Medium',
            on_time_delivery REAL DEFAULT 0,
            defect_rate REAL DEFAULT 0,
            avg_delay_days REAL DEFAULT 0,
            lead_time_days REAL DEFAULT 0,
            price_volatility REAL DEFAULT 0,
            capacity_utilization REAL DEFAULT 0,
            dependency_percentage REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS risk_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vendor TEXT NOT NULL,
            risk_score REAL NOT NULL,
            recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

def add_vendor(data):
    conn = get_connection()
    try:
        conn.execute("""
            INSERT INTO vendors (
                vendor, category, location, contract_value, criticality,
                on_time_delivery, defect_rate, avg_delay_days, lead_time_days,
                price_volatility, capacity_utilization, dependency_percentage
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data["vendor"], data["category"], data["location"],
            data["contract_value"], data["criticality"],
            data["on_time_delivery"], data["defect_rate"],
            data["avg_delay_days"], data["lead_time_days"],
            data["price_volatility"], data["capacity_utilization"],
            data["dependency_percentage"]
        ))
        conn.commit()
        return True, "Vendor added successfully."
    except sqlite3.IntegrityError:
        return False, "This vendor already exists."
    finally:
        conn.close()

def get_vendors():
    conn = get_connection()
    df = pd.read_sql_query("SELECT * FROM vendors ORDER BY id DESC", conn)
    conn.close()
    return df

def save_risk_history(vendor, score):
    conn = get_connection()
    conn.execute(
        "INSERT INTO risk_history (vendor, risk_score) VALUES (?, ?)",
        (vendor, score)
    )
    conn.commit()
    conn.close()

def get_risk_history(vendor):
    conn = get_connection()
    df = pd.read_sql_query(
        "SELECT vendor, risk_score, recorded_at "
        "FROM risk_history WHERE vendor=? ORDER BY recorded_at",
        conn,
        params=(vendor,)
    )
    conn.close()
    return df
