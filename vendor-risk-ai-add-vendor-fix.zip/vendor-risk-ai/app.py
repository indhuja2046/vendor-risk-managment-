import streamlit as st
import pandas as pd
import plotly.express as px
from database import (
    create_table, add_vendor, get_vendors,
    save_risk_history, get_risk_history
)

st.set_page_config(
    page_title="VendorGuard AI",
    page_icon="🏢",
    layout="wide"
)

create_table()

# ---------------- LOGIN ----------------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:
    st.title("🏢 VendorGuard AI")
    st.subheader("AI Vendor Risk Intelligence")

    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login", type="primary", use_container_width=True):
        if username == "admin" and password == "admin123":
            st.session_state.logged_in = True
            st.session_state.role = "Admin"
            st.rerun()
        elif username == "manager" and password == "manager123":
            st.session_state.logged_in = True
            st.session_state.role = "Manager"
            st.rerun()
        else:
            st.error("Invalid login.")

    st.info("Demo login: admin / admin123")
    st.stop()

# ---------------- RISK ENGINE ----------------
def calculate_risk(row):
    delivery = max(0, 100 - float(row["On_Time_Delivery"]))
    quality = min(100, float(row["Defect_Rate"]) * 5)
    delay = min(100, float(row["Avg_Delay_Days"]) * 7)
    lead = min(100, float(row["Lead_Time_Days"]) * 5)
    price = min(100, float(row["Price_Volatility"]) * 3)
    capacity = min(
        100,
        max(0, float(row["Capacity_Utilization"]) - 50) * 2
    )
    dependency = min(
        100,
        float(row["Dependency_Percentage"]) * 1.5
    )

    score = (
        delivery * 0.25
        + quality * 0.15
        + delay * 0.15
        + lead * 0.10
        + price * 0.10
        + capacity * 0.10
        + dependency * 0.15
    )
    return round(min(score, 100), 1)

def risk_level(score):
    if score <= 30:
        return "🟢 Low"
    if score <= 60:
        return "🟡 Medium"
    if score <= 80:
        return "🟠 High"
    return "🔴 Critical"

# ---------------- SAMPLE VENDORS ----------------
sample = pd.DataFrame({
    "Vendor": [
        "ABC Components", "Global Steel Ltd", "Prime Electronics",
        "FastLogix", "SafePack Industries", "TechSource",
        "Metro Materials", "Reliable Parts", "QuickSupply", "IndustrialPro"
    ],
    "Category": [
        "Components", "Steel", "Electronics", "Logistics", "Packaging",
        "Technology", "Materials", "Parts", "Supply", "Industrial"
    ],
    "Location": [
        "Chennai", "Coimbatore", "Bengaluru", "Chennai", "Pune",
        "Hyderabad", "Chennai", "Mumbai", "Chennai", "Coimbatore"
    ],
    "Contract_Value": [
        1200000, 1800000, 950000, 1500000, 800000,
        1100000, 1300000, 900000, 700000, 1600000
    ],
    "Criticality": [
        "High", "Critical", "High", "Critical", "Medium",
        "High", "Medium", "High", "Medium", "High"
    ],
    "On_Time_Delivery": [94, 68, 82, 55, 97, 88, 72, 91, 61, 78],
    "Defect_Rate": [2, 8, 5, 12, 1, 4, 9, 2, 11, 6],
    "Avg_Delay_Days": [1, 6, 3, 9, 1, 2, 5, 1, 8, 4],
    "Lead_Time_Days": [3, 8, 5, 12, 2, 4, 9, 3, 10, 6],
    "Price_Volatility": [3, 12, 7, 18, 2, 5, 14, 4, 16, 9],
    "Capacity_Utilization": [65, 88, 75, 95, 60, 70, 91, 62, 93, 80],
    "Dependency_Percentage": [15, 35, 25, 42, 10, 20, 38, 12, 45, 30]
})

# ---------------- DATABASE VENDORS ----------------
db = get_vendors()

if not db.empty:
    db = db.rename(columns={
        "vendor": "Vendor",
        "category": "Category",
        "location": "Location",
        "contract_value": "Contract_Value",
        "criticality": "Criticality",
        "on_time_delivery": "On_Time_Delivery",
        "defect_rate": "Defect_Rate",
        "avg_delay_days": "Avg_Delay_Days",
        "lead_time_days": "Lead_Time_Days",
        "price_volatility": "Price_Volatility",
        "capacity_utilization": "Capacity_Utilization",
        "dependency_percentage": "Dependency_Percentage"
    })

    db = db[sample.columns]
    df = pd.concat([sample, db], ignore_index=True)
    df = df.drop_duplicates("Vendor", keep="last")
else:
    df = sample.copy()

df["Risk_Score"] = df.apply(calculate_risk, axis=1)
df["Risk_Level"] = df["Risk_Score"].apply(risk_level)

# ---------------- SIDEBAR ----------------
st.sidebar.title("🏢 VendorGuard AI")

role = st.session_state.get("role", "Manager")

pages = [
    "📊 Dashboard",
    "🔍 Vendor Analysis",
    "🔮 Future Prediction",
    "🧪 What-If Simulation",
    "🌐 Supply Chain Impact",
    "🔄 Alternative Vendor",
    "🤖 AI Decision"
]

if role == "Admin":
    pages.append("➕ Add Vendor")

page = st.sidebar.radio("Navigation", pages)

if st.sidebar.button("Logout", use_container_width=True):
    st.session_state.logged_in = False
    st.rerun()

# ---------------- ADD VENDOR ----------------
if page == "➕ Add Vendor":
    st.title("➕ Add New Vendor")
    st.write(
        "Enter the vendor details below. "
        "After saving, the vendor is stored in the database "
        "and can be analyzed immediately."
    )

    with st.form("vendor_form"):
        left, right = st.columns(2)

        with left:
            vendor_name = st.text_input(
                "Vendor Name *",
                placeholder="Example: Delta Components"
            )
            category = st.text_input("Category", value="General")
            location = st.text_input("Location", value="Chennai")
            contract_value = st.number_input(
                "Contract Value (₹)",
                min_value=0.0,
                value=1000000.0,
                step=50000.0
            )
            criticality = st.selectbox(
                "Criticality",
                ["Low", "Medium", "High", "Critical"],
                index=1
            )
            on_time = st.number_input(
                "On-Time Delivery (%)",
                min_value=0.0, max_value=100.0, value=90.0
            )
            defect = st.number_input(
                "Defect Rate (%)",
                min_value=0.0, max_value=100.0, value=3.0
            )

        with right:
            delay = st.number_input(
                "Average Delay (days)",
                min_value=0.0, max_value=365.0, value=2.0
            )
            lead = st.number_input(
                "Lead Time (days)",
                min_value=0.0, max_value=365.0, value=7.0
            )
            price = st.number_input(
                "Price Volatility (%)",
                min_value=0.0, max_value=100.0, value=5.0
            )
            capacity = st.number_input(
                "Capacity Utilization (%)",
                min_value=0.0, max_value=100.0, value=70.0
            )
            dependency = st.number_input(
                "Dependency (%)",
                min_value=0.0, max_value=100.0, value=20.0
            )

        save = st.form_submit_button(
            "💾 SAVE VENDOR",
            type="primary",
            use_container_width=True
        )

    if save:
        name = vendor_name.strip()

        if not name:
            st.error("Please enter Vendor Name.")
        else:
            vendor_data = {
                "vendor": name,
                "category": category.strip() or "General",
                "location": location.strip() or "Not specified",
                "contract_value": contract_value,
                "criticality": criticality,
                "on_time_delivery": on_time,
                "defect_rate": defect,
                "avg_delay_days": delay,
                "lead_time_days": lead,
                "price_volatility": price,
                "capacity_utilization": capacity,
                "dependency_percentage": dependency
            }

            ok, message = add_vendor(vendor_data)

            if ok:
                score_row = pd.Series({
                    "On_Time_Delivery": on_time,
                    "Defect_Rate": defect,
                    "Avg_Delay_Days": delay,
                    "Lead_Time_Days": lead,
                    "Price_Volatility": price,
                    "Capacity_Utilization": capacity,
                    "Dependency_Percentage": dependency
                })

                score = calculate_risk(score_row)
                save_risk_history(name, score)

                st.success(f"✅ {name} added successfully!")
                st.metric("Initial Risk Score", f"{score}/100")
                st.write(f"Risk Level: **{risk_level(score)}**")
                st.info(
                    "Go to **Vendor Analysis** and select "
                    "this vendor from the Vendor dropdown."
                )

            else:
                st.error(message)

    st.divider()
    st.subheader("📋 Vendors Saved in Database")

    saved = get_vendors()

    if saved.empty:
        st.info("No vendors have been added yet.")
    else:
        display = saved.rename(columns={
            "vendor": "Vendor",
            "category": "Category",
            "location": "Location",
            "criticality": "Criticality",
            "created_at": "Added At"
        })
        st.dataframe(
            display[
                ["Vendor", "Category", "Location",
                 "Criticality", "Added At"]
            ],
            use_container_width=True,
            hide_index=True
        )

    st.stop()

# ---------------- SELECT VENDOR ----------------
selected_vendor = st.sidebar.selectbox(
    "Select Vendor",
    df["Vendor"].tolist()
)

vendor = df[df["Vendor"] == selected_vendor].iloc[0]
current_score = float(vendor["Risk_Score"])

st.title("🏢 VendorGuard AI")
st.caption(
    "Detect → Explain → Predict → Simulate → Impact → Recommend → Prevent"
)

# ---------------- DASHBOARD ----------------
if page == "📊 Dashboard":
    st.header("📊 Vendor Risk Dashboard")

    a, b, c, d = st.columns(4)
    a.metric("Total Vendors", len(df))
    b.metric("Low Risk", int((df["Risk_Score"] <= 30).sum()))
    c.metric("High Risk", int((df["Risk_Score"] > 60).sum()))
    d.metric("Critical", int((df["Risk_Score"] > 80).sum()))

    chart = px.bar(
        df.sort_values("Risk_Score", ascending=False),
        x="Vendor",
        y="Risk_Score",
        title="Vendor Risk Comparison"
    )
    st.plotly_chart(chart, use_container_width=True)

    st.dataframe(
        df[
            ["Vendor", "Category", "Criticality",
             "On_Time_Delivery", "Defect_Rate",
             "Risk_Score", "Risk_Level"]
        ],
        use_container_width=True,
        hide_index=True
    )

# ---------------- VENDOR ANALYSIS ----------------
elif page == "🔍 Vendor Analysis":
    st.header(f"🔍 Vendor Analysis — {selected_vendor}")

    a, b, c = st.columns(3)
    a.metric("Risk Score", f"{current_score}/100")
    b.metric("Risk Level", vendor["Risk_Level"])
    c.metric("On-Time Delivery", f"{vendor['On_Time_Delivery']}%")

    factors = pd.DataFrame({
        "Risk Factor": [
            "Delivery", "Quality", "Delay", "Lead Time",
            "Price", "Capacity", "Dependency"
        ],
        "Risk": [
            100 - vendor["On_Time_Delivery"],
            min(100, vendor["Defect_Rate"] * 5),
            min(100, vendor["Avg_Delay_Days"] * 7),
            min(100, vendor["Lead_Time_Days"] * 5),
            min(100, vendor["Price_Volatility"] * 3),
            min(100, max(0, vendor["Capacity_Utilization"] - 50) * 2),
            min(100, vendor["Dependency_Percentage"] * 1.5)
        ]
    })

    st.plotly_chart(
        px.bar(
            factors,
            x="Risk Factor",
            y="Risk",
            title="Risk Contributors"
        ),
        use_container_width=True
    )

    st.subheader("🧠 Why is this vendor risky?")

    reasons = []
    if vendor["On_Time_Delivery"] < 80:
        reasons.append(
            f"Low on-time delivery: {vendor['On_Time_Delivery']}%"
        )
    if vendor["Defect_Rate"] > 7:
        reasons.append(
            f"High defect rate: {vendor['Defect_Rate']}%"
        )
    if vendor["Avg_Delay_Days"] > 5:
        reasons.append(
            f"High average delay: {vendor['Avg_Delay_Days']} days"
        )
    if vendor["Lead_Time_Days"] > 8:
        reasons.append(
            f"Long lead time: {vendor['Lead_Time_Days']} days"
        )
    if vendor["Price_Volatility"] > 10:
        reasons.append(
            f"High price volatility: {vendor['Price_Volatility']}%"
        )
    if vendor["Capacity_Utilization"] > 90:
        reasons.append(
            f"High capacity utilization: {vendor['Capacity_Utilization']}%"
        )
    if vendor["Dependency_Percentage"] > 35:
        reasons.append(
            f"High dependency: {vendor['Dependency_Percentage']}%"
        )

    if reasons:
        for reason in reasons:
            st.warning(reason)
    else:
        st.success("Vendor performance is currently stable.")

    st.subheader("📋 Vendor Details")

    details = pd.DataFrame({
        "Metric": [
            "Category", "Location", "Contract Value", "Criticality",
            "On-Time Delivery", "Defect Rate", "Average Delay",
            "Lead Time", "Price Volatility",
            "Capacity Utilization", "Dependency"
        ],
        "Value": [
            vendor["Category"],
            vendor["Location"],
            f"₹{vendor['Contract_Value']:,.0f}",
            vendor["Criticality"],
            f"{vendor['On_Time_Delivery']}%",
            f"{vendor['Defect_Rate']}%",
            f"{vendor['Avg_Delay_Days']} days",
            f"{vendor['Lead_Time_Days']} days",
            f"{vendor['Price_Volatility']}%",
            f"{vendor['Capacity_Utilization']}%",
            f"{vendor['Dependency_Percentage']}%"
        ]
    })

    st.dataframe(
        details,
        use_container_width=True,
        hide_index=True
    )

    history = get_risk_history(selected_vendor)
    if not history.empty:
        st.subheader("📈 Risk History")
        st.line_chart(
            history.set_index("recorded_at")["risk_score"]
        )

# ---------------- FUTURE PREDICTION ----------------
elif page == "🔮 Future Prediction":
    st.header("🔮 Future Risk Prediction")

    factor = (
        1.18 if vendor["On_Time_Delivery"] < 70
        else 1.10 if vendor["On_Time_Delivery"] < 85
        else 0.95
    )

    r30 = min(100, round(current_score * factor, 1))
    r60 = min(100, round(r30 * factor, 1))
    r90 = min(100, round(r60 * factor, 1))

    forecast = pd.DataFrame({
        "Period": ["Current", "30 Days", "60 Days", "90 Days"],
        "Risk": [current_score, r30, r60, r90]
    })

    st.plotly_chart(
        px.line(
            forecast,
            x="Period",
            y="Risk",
            markers=True,
            title="Risk Forecast"
        ),
        use_container_width=True
    )

    a, b, c = st.columns(3)
    a.metric("30-Day", f"{r30}/100")
    b.metric("60-Day", f"{r60}/100")
    c.metric("90-Day", f"{r90}/100")

    if r90 > current_score:
        st.warning(
            "⚠️ Risk is projected to increase. "
            "Preventive action is recommended."
        )
    else:
        st.success("Risk is stable or projected to improve.")

# ---------------- WHAT IF ----------------
elif page == "🧪 What-If Simulation":
    st.header("🧪 What-If Risk Simulation")

    delay = st.slider("Additional Delay (days)", 0, 30, 0)
    order = st.slider("Order Increase (%)", 0, 100, 0)

    simulated = min(
        100,
        round(current_score + delay * 2 + order * 0.15, 1)
    )

    a, b, c = st.columns(3)
    a.metric("Current Risk", f"{current_score}/100")
    b.metric("Simulated Risk", f"{simulated}/100")
    c.metric("Risk Change", f"{simulated - current_score:+.1f}")

    if simulated > 80:
        st.error("🔴 Critical scenario.")
    elif simulated > 60:
        st.warning("🟠 High-risk scenario.")
    elif simulated > 30:
        st.info("🟡 Medium-risk scenario.")
    else:
        st.success("🟢 Low-risk scenario.")

# ---------------- IMPACT ----------------
elif page == "🌐 Supply Chain Impact":
    st.header("🌐 Supply Chain Impact")

    production = min(
        100,
        round(
            vendor["Dependency_Percentage"] * 0.7
            + vendor["Avg_Delay_Days"] * 2,
            1
        )
    )
    quality = min(100, round(vendor["Defect_Rate"] * 7, 1))
    delivery = min(
        100,
        round((100 - vendor["On_Time_Delivery"]) * 1.2, 1)
    )
    overall = round(
        (production + quality + delivery) / 3,
        1
    )

    a, b, c = st.columns(3)
    a.metric("Production Impact", f"{production}%")
    b.metric("Quality Impact", f"{quality}%")
    c.metric("Delivery Impact", f"{delivery}%")

    st.progress(int(overall))
    st.write(f"Estimated Overall Impact: **{overall}%**")
    st.info(
        "Vendor disruption → Supply delay → Production impact "
        "→ Customer delivery impact → Potential business loss"
    )

# ---------------- ALTERNATIVE ----------------
elif page == "🔄 Alternative Vendor":
    st.header("🔄 Alternative Vendor Recommendation")

    alternatives = df[df["Vendor"] != selected_vendor].copy()

    alternatives["Recommendation_Score"] = (
        alternatives["Risk_Score"] * 0.5
        + alternatives["Defect_Rate"] * 2
        + alternatives["Avg_Delay_Days"] * 2
        + alternatives["Dependency_Percentage"] * 0.5
    )

    alternatives = alternatives.sort_values(
        "Recommendation_Score"
    ).head(5)

    st.dataframe(
        alternatives[
            [
                "Vendor", "Risk_Score",
                "On_Time_Delivery", "Defect_Rate",
                "Avg_Delay_Days"
            ]
        ],
        use_container_width=True,
        hide_index=True
    )

    if not alternatives.empty:
        best = alternatives.iloc[0]
        st.success(
            f"⭐ Recommended: {best['Vendor']} — "
            f"Risk {best['Risk_Score']}/100"
        )

# ---------------- AI DECISION ----------------
elif page == "🤖 AI Decision":
    st.header("🤖 AI Decision Center")

    factor = (
        1.18 if vendor["On_Time_Delivery"] < 70
        else 1.10 if vendor["On_Time_Delivery"] < 85
        else 0.95
    )

    risk_90 = min(
        100,
        round(current_score * factor ** 3, 1)
    )

    if current_score > 80:
        level = "🔴 CRITICAL"
        action = (
            "Prepare a backup supplier and reduce dependency."
        )
    elif current_score > 60:
        level = "🟠 HIGH"
        action = (
            "Closely monitor the vendor and prepare an alternative."
        )
    elif current_score > 30:
        level = "🟡 MEDIUM"
        action = (
            "Monitor delivery, quality and capacity."
        )
    else:
        level = "🟢 LOW"
        action = "Continue regular monitoring."

    a, b, c = st.columns(3)
    a.metric("Current Risk", f"{current_score}/100")
    b.metric("Alert Level", level)
    c.metric("90-Day Risk", f"{risk_90}/100")

    st.success(f"🎯 Recommended Action: {action}")
